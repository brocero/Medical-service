<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet"	href="style/style.css"	
type="text/css"	media="screen"	/>	
</head>
<body>
	<h1><img src='image/logo.png' class='logo'> </h1>
 
  
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
	<div class='inscription'>
		
		<h2> Je m'inscris : </h2>
		<form method="POST" action="enregistrement.php" autocomplete="off">
			<p>Nom : <INPUT type="text" name="n" value=<?php echo $_POST['n']?> ></p>
			<p>Prenom : <INPUT type="text" name="p" value=<?php echo $_POST['p']?> > </p>
			<p>Région : <INPUT type="text" name="reg" value=<?php echo $_POST['reg']?> > </p>
			<p>Département : <INPUT type="text" name="dep" value=<?php echo $_POST['dep']?> > </p>
			<p>Adresse e-mail : <INPUT type="text" name="mail" value=<?php echo $_POST['mail']?> > </p>
			<p>Mot de passe : <INPUT type="password" name="mdp1" value=<?php echo $_POST['mdp1']?> ></p>
			<p>Confirmer le mot de passe : <INPUT type="password" name="mdp2" value=<?php echo $_POST['mdp2']?> > </p>
			<p><input type="submit" value="Envoyer"> </p>
		</form> 
	</div>
	
	<img src='image/inscription.jpg'>
	
	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>
	
</body>
</html>