<html>
<head>
 <link rel="stylesheet"	href="style/style.css"	
type="text/css"	media="screen"	/>	
</head>
<body>
<form method="get" action="enregistrement.php" autocomplete="on">
	<p>Nom : <INPUT type="text" name="n" value=<?php echo $_GET['n']?> ></p>
	<p>Prenom : <INPUT type="text" name="p" value=<?php echo $_GET['p']?> > </p>
	<p>Région : <INPUT type="text" name="reg" value=<?php echo $_GET['reg']?> > </p>
	<p>Département : <INPUT type="text" name="dep" value=<?php echo $_GET['dep']?> > </p>
	<p>Adresse e-mail : <INPUT type="text" name="mail" value=<?php echo $_GET['mail']?> > </p>
	<p>Mot de passe : <INPUT type="password" name="mdp1" value=<?php echo $_GET['mdp1']?> ></p>
	<p>Confirmer le mot de passe : <INPUT type="password" name="mdp2" value=<?php echo $_GET['mdp2']?> > </p>
	<p><input type="submit" value="Envoyer"> </p>
</form> 
<p><a href = "index.php">retour</a></p>
</body>
</html>