<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>
 
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>

	<img src="image/images.jpeg" class='ima'>
	
	<div class="onglet">
		<table class='eff'>
	
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			//print_r($_GET);
			
			$req='select nom_spe, sum(situer.effectif) as somme, departement.nom_dep from departement, iris, situer, specialite where iris.id_iris=situer.id_iris
			and specialite.code_spe=situer.code_spe and iris.code_dep=departement.code_dep and situer.effectif != 0 
			and departement.code_dep='.$_GET["idd"].' GROUP by specialite.nom_spe ORDER by specialite.nom_spe ASC';
			
			//echo $req;
			
			$rep = $bdd->query($req);
			
			$ligne = $rep ->fetch();
			echo '<tr><th> Nom de la spécialité </th>
				<th> Effectif par spécialité dans le département '.$ligne['nom_dep'].'</th></tr>';
			
			echo '<tr><td class="cell">'.$ligne['nom_spe'].'</td>';
			echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			
			while ($ligne = $rep ->fetch()){
				echo '<tr><td class="cell">'.$ligne['nom_spe'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>
	
	
	<a href='localite.php' class='retour'>Retour</a>
	
	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Source</a></th>
		</tr>
	</table>

</body>
</html>