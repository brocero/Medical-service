<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet"	href="style/style.css"	type="text/css"	media="screen"	/>	
 
<?php

	function enregistre ($nom, $prenom, $region, $departement, $mail, $mdp)
	{
		$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
		
		$req = 'INSERT INTO utilisateur VALUES (NULL,"'.$nom.'","'.$prenom.'","'.$region.'","'.$departement.'","'.$mail.'","'.$mdp.'")';
		//echo $req;
		
		$rep = $bdd->query($req);
		
	}

	if($_POST['n']=="" || $_POST['p']=="" || $_POST['reg']=="" || $_POST['mail']=="" || $_POST['dep']=="" 
		|| $_POST['mdp1']=="" || $_POST['mdp2']=="" || $_POST['mdp1']!=$_POST['mdp2']) {
		echo "<meta http-equiv='refresh' content='0; URL=nouveau.php?n=".$_POST['n']."&p=".$_POST['p']."&reg=".$_POST['reg'].
		"&dep=".$POST['dep']."&mail=".$_POST['mail']."'>" ;
	}
	else{
		enregistre ($_POST['n'], $_POST['p'], $_POST['reg'], $_POST['dep'], $_POST['mail'], $_POST['mdp1']);
		echo "<meta http-equiv='refresh' content='0; URL=index.php'>" ;
	}

?>

</head>
<body>



</body>
</html>