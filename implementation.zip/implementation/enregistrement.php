<html>
<head>
 <link rel="stylesheet"	href="style/style.css"	type="text/css"	media="screen"	/>	
<?php

if($_GET['n']=="" || $_GET['p']=="" || $_GET['reg']=="" || $_GET['mail']=="" || $_GET['dep']=="" 
		|| $_GET['mdp1']=="" || $_GET['mdp2']=="" || $_GET['mdp1']!=$_GET['mdp2']) {
		echo "<meta http-equiv='refresh' content='0; URL=nouveau.php?n=".$_GET['n']."&p=".$_GET['p']."&reg=".$_GET['reg'].
		"&dep=".$_GET['dep']."&mail=".$_GET['mail']."'>" ;
}
else{
	echo "<meta http-equiv='refresh' content='0; URL=index.php'>" ;
}

?>

</head>
<body>



</body>
</html>