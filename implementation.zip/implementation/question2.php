<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
	
<h1><img src='image/logo.png' class='logo'> </h1>
 
  
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
	<h2>Où sont les informations sur la Corse-du-Sud et la Haute-Corse ?</h2>
	<div class="boite">
		<p> Suite à problème de lecture des numéros de départements 2A et 2B dans la base de données, nous avons décidé de les "renommer" respectivement 200 et 201.</p>
		<p> Ainsi, la Corse-du-Sud correspond au département 200, et la Haute-Corse au 201. Ces informations sont disponibles également sur la <a href="index.php">page d'accueil</a>. </p>
		<p> <a href="FAQ.php">Retour</a></p>
	</div>
 

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>