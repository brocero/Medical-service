<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>
 
  
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
	<h2>Sources</h2>
	<div class="boite">
		<ul>
			<li>Récupération des données sur l'INSEE :
				<ul><br><li><a href='https://www.insee.fr/fr/information/2114819'> Code officiel géographique au 1er janvier 
					2016 </a></li><br>
					<li><a href='https://www.insee.fr/fr/statistiques/1893251?sommaire=2044564'> Nombre d'équipements en 
					2016 (commerces, services, santé...) </a></li>
				</ul>
			</li><br>
			<li>Aide à l'implémentation :<a href='http://www.phpdebutant.org/forum_msg300372.php'> PHPdebutant </a></li>
		</ul>
	</div>
 
	<img src='image/INSEE.jpg'>

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>