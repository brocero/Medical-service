<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
 <h1>Medical Service </h1>

 <div class="boite"><h2>Contact</h2>
	<div class="romain"> 
		<ul>
			<li><h3>Bialek Romain</h3></li>
			<li>Adresse mail : romain.bialek@etu.univ-montp3.fr </li>
			<li>Age : 15/01/1997</li>
			<li>Formation : Licence MIASHS 3ème année </li>
			<li>Lieu de formation : Université Paul Valéry Montpellier</li>
		</ul>
	</div>
	
		<div class="Alexia"> 
		<ul>
			<li><h3>Brocero Alexia</h3></li>
			<li>Adresse mail : alexia.brocero@etu.univ-montp3.fr </li>
			<li>Age : 03/04/1996</li>
			<li>Formation : Licence MIASHS 3ème année </li>
			<li>Lieu de formation : Université Paul Valéry Montpellier</li>
		</ul>
	</div>
	
 </div>
 
<p><a href="index.php">Accueil</a></p>

<table class="tab">
	<tr><th class="footer"><a href="CGU.php">CGU</a></th>
		<th class="footer"><a href="FAQ.php">FAQ</a></th>
		<th class="footer"><a href="contact.php">Contact</a></th>
		<th class="footer"><a href="source.php">Source</a></th>
	</tr>
</table>

</body>
</html>