<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
	
<h1><img src='image/logo.png' class='logo'> </h1>
 
  
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>

	<h2>Contact</h2>
	<div class="romain"> 
		<img src='image/romain.jpg' class='photo'>
		<h3>Bialek Romain</h3>
		<ul>
			<li>Adresse mail : romain.bialek@etu.univ-montp3.fr </li><br>
			<li>Date de naissance : 15/01/1997</li><br>
			<li>Formation : Licence MIASHS 3ème année </li><br>
			<li>Lieu de formation : Université Paul Valéry Montpellier</li><br>
		</ul>
	</div>
	
	<div class="alexia"> 
		<img src='image/alexia.jpeg' class='photo'>
		<h3>Brocero Alexia</h3>
		<ul>
			<li>Adresse mail : alexia.brocero@etu.univ-montp3.fr </li><br>
			<li>Date de naissance : 03/04/1996</li><br>
			<li>Formation : Licence MIASHS 3ème année </li><br>
			<li>Lieu de formation : Université Paul Valéry Montpellier</li><br>
		</ul>
	</div>
	

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>