
<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"	/>
</head>
<body>

 <?php
$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8',
'root', 'root'); 
?>

<h1><img src='image/logo.png' class='logo'> </h1>

<?php
	session_start();
	if(!isset($_SESSION['client'])){
		echo  '<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="nouveau.php"> Inscription</a></h2></th>
					</tr>
			</table>'.'<div class="recherche"><form  method="get" action="connecter.php" autocomplete="on">
			<h3>Déjà inscrit ?</h3>
			<br>Adresse mail : <input type = "text" name="mail" value=""></br>
			<br>Mot de passe : <input type = "password" name="mdp1" value=""></br>
			<br><input type="submit" value="Se connecter"></br>
			</form></div>';
	}
	else {
		$client=$_SESSION['client'];	
		echo '<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
					</tr>
			</table>'.'<div class="recherche">'.'Bonjour'." ".$client['prenom']." ".$client['nom'].'<br>'.
			'<a href="deconnecter.php" >Se déconnecter</a><br></div>';
	}
?>
</div>

 <!-- zone de recherche dynamique créer formulaire avec des div et form -->
	<div class="block_presentation"><h3> Présentation du site :</h3>
		<p>L'objectif principal de Medical Service est d'aider toute personne habile avec les nouvelles technologies 
		OU PAS ! <br>
		Nous vous proposons de trouver un service médical de votre choix avec plusieurs possibilités de recherches.
		Ce site facile d'accès, facile d'utilisation et donnant des résultats de façon efficace.</p>
		<p>Alors, vous souhaitez savoir s'il y a une spécialité X à Lyon ? Ou encore savoir quels services sont présents
		aux alentours d'une localité Y et en quel effectif ?  <br>
		Alors vous êtes au bon endroit ! En quelques « clics » et quelques secondes, vous aurez vos réponses !</p>
		<p>Pour plus de renseignements, contactez-nous, ou posez-vos questions sur notre FAQ.</p>
	</div> 
	
	<div class="block_aide"><h3>Aide au fonctionnement du site : </h3><p>Tout d'abord, si cela n'est pas encore fait, 
		nous vous recommandons de vous inscrire sur le site, via l'onglet « Inscription ». 
		Une fois l'inscription effectuée connectez-vous afin de nous faire part de votre avis et de vos commentaires.</p>

		<p>Deux fonctions principales s'offrent à vous :<br>
			- Si vous souhaitez rechercher les services disponibles 
		dans une région, un département ou une ville, cliquez sur l'onglet Localité. La recherche se fera de façon progressive
		partant du choix d'une région jusqu'à une ville.
			- Si, en revanche, vous voulez savoir où se trouve un service spécifique, c'est dans l'onglet Spécialité. 
		Vous choisirez la spécialité en amont puis une localité plus ou moins étendue selon votre choix.</p>
	
		<p>ATTENTION : Les identifiants des départements Haute-Corse et Corse du Sud sont respectivement le 201 et 200.</p>
	
		<p>Enfin, pour faciliter et affiner les recherches, nous avons décidé d'utiliser des codes IRIS. Ceux-ci on était
		créé par l'INSEE et on pour but de fractionner les villes d'au moins 10 000 habitants, ce qui nous permet, ici, de cibler des 
		zones précises. Cet outil est très utile notamment quand les recherches s'effectuent sur de grandes villes.<br>
		Voici des liens qui vous permetttront de vous renseigner plus précisemment sur les code IRIS : <br>
			- <a href="https://www.insee.fr/fr/metadonnees/definition/c1523" target='_blank'>Définition d'un IRIS</a><br>
			- <a href="https://www.insee.fr/fr/information/2017499" target='_blank'>Découpage infracommunal</a>
		</p>
	</div>
	
<table class="tab">
	<tr>
		<th class="footer"><a href="FAQ.php">FAQ</a></th>
		<th class="footer"><a href="contact.php">Contact</a></th>
		<th class="footer"><a href="source.php">Sources</a></th>
	</tr>
</table>


</body>
</html> 