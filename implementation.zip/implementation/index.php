<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"	/>
</head>
<body>

 <?php
$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8',
'root', 'root'); 
?>

<h1>Medical Service </h1>

<table class="tab">
	<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
		<th><h2><a href="localite.php">Localité</a></h2></th>
		<th><h2><a href="nouveau.php"> Inscription</a></h2></th>
		</tr>
</table>

 <!-- zone de recherche dynamique créer formulaire avec des div et form -->
	<div class="block_presentation"><p> Présentation du site dans le bloc </p></div>
	<div class="recherche"><form><h3>Déjà inscrit ?</h3>
						<br>Adresse mail : <input type = "text"></br>
						<br>Mot de passe : <input type = "text"></br>
						</form></div>
	<div class="block_aide"><p> Aide au fonctionnement du site dans le bloc</p></div>
	
<table class="tab">
	<tr><th class="footer"><a href="CGU.php">CGU</a></th>
		<th class="footer"><a href="FAQ.php">FAQ</a></th>
		<th class="footer"><a href="contact.php">Contact</a></th>
		<th class="footer"><a href="source.php">Source</a></th>
	</tr>
</table>

</body>
</html> 