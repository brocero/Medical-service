<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet"	href="style/style.css"	type="text/css"	media="screen"/>	
		<title>Déconnexion</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
		<?php
			session_start();
			session_destroy();
			echo "<meta http-equiv='Refresh' content='0; url=index.php' />"
		?>
	</head>