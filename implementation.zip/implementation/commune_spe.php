<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>

	<table class="tab">
					<tr><th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
 
	<!--<div class="recherche_spe"> ;
		<form>	
			<br>Recherche par spécialité : <input type = "text"></br>
		</form>
	</div> -->
 <img src="image/docteur.jpeg" class='ima'>	
	<div class="onglet">
		<table class='eff'>
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			//print_r($_GET);
			
			$requete = "select commune.lib_com, sum(situer.effectif) as somme, specialite.nom_spe from commune, iris, situer,
				specialite where iris.id_iris=situer.id_iris and situer.code_spe=specialite.code_spe and 
				iris.code_com=commune.code_com and situer.effectif != 0 and commune.code_dep = ".$_GET["idd"].
				"and iris.code_dep= ".$_GET["idd"].
				" and situer.code_spe= ".$_GET["ids"]." group by commune.lib_com order by lib_com ASC";
				
			//echo $requete;
			
			$rep = $bdd->query($requete); 
			
			$ligne = $rep ->fetch();
			
			echo '<h3>Effectif de la specialite ';
			echo $ligne['nom_spe'].' par commune</h3>';
			
			echo '<tr><th> Nom de la commune </th>
				<th> Effectif total : </th></tr>';
			echo '<tr><td class="eff">'.$ligne['lib_com'].'</td>';
			echo '<td class="eff">'.$ligne['somme'].'</td></tr>';
				
				
			while ($ligne = $rep ->fetch()){
				echo '<tr><td class="eff">'.$ligne['lib_com'].'</td>';
				echo '<td class="eff">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>
	
	<div class='stat'>
		<table class="eff">
		<?php	
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			
			$req='select effectif, lib_iris, nom_spe, lib_com from situer, specialite, iris, commune,
			departement where situer.code_spe=specialite.code_spe and iris.code_com=commune.code_com and 
			situer.id_iris=iris.id_iris and iris.code_dep=departement.code_dep and situer.code_spe= '.$_GET["ids"].
			' and iris.code_dep='.$_GET["idd"].' group by lib_iris order by lib_com';
			
			//echo $req;
			
			$rep = $bdd->query($req); 
			
			$ligne = $rep ->fetch();
			
			echo '<h3>Effectif de la specialite ';
			echo $ligne['nom_spe'].' dans chaque iris</h3>';
			echo "<tr><th>Nom de l'iris</th><th>Commune</th><th>Effectif</th></tr>";
			
			echo '<tr><td class="cell">'.$ligne['lib_iris'].'</td>';
			echo '<td class="cell">'.$ligne['lib_com'].'</td>';
			echo '<td class="cell">'.$ligne['effectif'].'</td></tr>';
			
			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['lib_iris'].'</td>';
				echo '<td class="cell">'.$ligne['lib_com'].'</td>';
				echo '<td class="cell">'.$ligne['effectif'].'</td></tr>';
			}
		?>
		</table>
	</div>

	
	<a href='specialite.php' class='retour'>Retour</a>
	
	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>