<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
	
<h1><img src='image/logo.png' class='logo'> </h1>
 
  
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
	<h2>Pourquoi remplir des champs département et région à l'inscription ?</h2>
	<div class="boite">
		<p> Ces champs nous permettent de déterminer votre lieu d'habitation beaucoup plus rapidement lors de votre conexion, et, de ce fait de (peut-être) faciliter vos recherches en vous mettant d'avance quelques résultats correspondant à vos lieux renseignés.</p>
		<p> Par exemple, quand vous irez dans la page localité, vous aurez les résultats relatifs à votre région.</p>
		<p> <a href="FAQ.php">Retour</a></p>
	</div>
 

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>