<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
	
<h1><img src='image/logo.png' class='logo'> </h1>
 
  
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
	<h2>Où sont les informations sur la Corse-du-Sud et la Haute-Corse ?</h2>
	<div class="boite">
		<p><h4> La page Spécialité</h4></p>
		<p> En cliquant sur "Spécialité", vous arrivez sur une page où vous trouvez une liste de toutes celles-ci.</p>
		<p> Il vous suffit de cliquer sur celle qui vous intéresse (où que vous recherchez), afin d'arriver sur une page où s'affichent toutes les régions dans laquelle elle se trouve.<p>
		<p> De la même manière, en cliquant sur la région de votre choix, vous aurez la liste des départements de cette région où la spécialité est disponible. <p>
		<p> Si, toutefois, vous souhaitez affiner un peu plus votre recherche, vous pouvez cliquer sur un département afin de trouver une liste des communes de celui-ci où la spécialité choisie auparavant est disponible.</p>
		<p> <a href="FAQ.php">Retour</a></p>
	</div>
	<div class="boite">
		<p><h4> La page Localité</h4></p>
		<p> En cliquant sur "Localité", vous arrivez sur une page où vous trouvez une liste de toutes les régions de France.</p>
		<p> Il vous suffit de cliquer sur celle qui vous intéresse (où que vous recherchez), afin d'arriver sur une page où s'affichent tous les départements de cette région.<p>
		<p> De la même manière, en cliquant sur le département de votre choix, vous aurez la liste des spécialités disponibles dans celui-ci. <p>
		<p> Dans le cas où vous préféreriez trouvez toutes les spécialités disponibles dans une commune, une liste déroulante vous est proposée lorsque vous cliquez sur "Localité". Dans cette liste, il vous suffit de trouver la commune que vous recherchez, et vous aurez les informations relatives à celle-ci.</p>
	</div>
	
	
 

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>