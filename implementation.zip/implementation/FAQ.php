<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
 <h1>Medical Service </h1>

 <div class="boite"> <h2>Foire aux questions<</h2

 
 
 </div>
 
<p><a href="index.php">Accueil</a></p>

<table class="tab">
	<tr><th class="footer"><a href="CGU.php">CGU</a></th>
		<th class="footer"><a href="FAQ.php">FAQ</a></th>
		<th class="footer"><a href="contact.php">Contact</a></th>
		<th class="footer"><a href="source.php">Source</a></th>
	</tr>
</table>

</body>
</html>