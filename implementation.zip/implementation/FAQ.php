<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
	
<h1><img src='image/logo.png' class='logo'> </h1>
 
  
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
	<h2>Foire aux questions</h2>
	<img src='image/point.png'>
	<div class="boite">
		<p> Vous vous posez quelques questions sur le fonctionnement du site ? Ou bien, sur l'utilité de certaines fonctions du site ?</p>
		<p> Quoi qu'il en soit, la foire aux questions est faite pour cela. Vous trouverez ci-dessous les questions les plus fréquentes, ou celles qui nous paraissent les plus pertinentes.</p>
		<p> Si vous ne trouvez pas la réponse que vous cherchiez, il est bien évidemment possible de <a href="contact.php">nous contacter</a></th> directement.</p>
		<p><a href="question1.php"> Pourquoi mettre mon département et ma région lorsque je m'inscris ?</a></p>
		<p><a href="question2.php"> Comment trouver les informations des départements de la Corse ?</a></p>
		<p><a href="question3.php"> Comment utiliser au mieux les pages Spécialité/Localité ?</a></p>
	</div>
 

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>