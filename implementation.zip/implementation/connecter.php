<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet"	href="style/style.css"	type="text/css"	media="screen"/>	
		<title>Connecter</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
		<?php
			if ($_GET['mail']=="" || $_GET['mdp1']==""){
				echo "<meta http-equiv='Refresh' content='0; url=index.php' />";
			}
			$bdd = new PDO("mysql:host=localhost;dbname=projet_l3;charset=utf8", "root", "root");
			
			$req = $bdd -> query("select nom, prenom, region, departement from utilisateur where mail = '".$_GET['mail']."' and mdp = '".$_GET['mdp1']."';");
			$client= $req -> fetch();
			
			if($client==""){echo "<meta http-equiv='Refresh' content='0; url=index.php' />";
			}
			else {
			session_start();
			$_SESSION['client'] = array('nom' => $client['nom'],'prenom' => $client['prenom'],'mail' => $_GET['mail'],'region' => $client['region'],'departement' => $client['departement']);
			echo "<meta http-equiv='Refresh' content='0; url=index.php' />";              
			}                
			                 
		?>                   
	</head>                  