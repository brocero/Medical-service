<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>

	<table class="tab">
					<tr><th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
 
  <img src="image/docteur.jpeg" class='ima'>	
  
	<!--<div class="recherche_spe"> ;
		<form>	
			<br>Recherche par spécialité : <input type = "text"></br>
		</form>
	</div> -->

	<div class="onglet">
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			//print_r($_GET);
			$requete = "select distinct departement.nom_dep, departement.code_dep, situer.code_spe from departement, iris, situer
			where iris.id_iris=situer.id_iris and departement.code_dep=iris.code_dep and situer.effectif != 0 and
			iris.code_reg = ".$_GET["idr"]." and code_spe= ".$_GET["ids"]." order by departement.nom_dep";
			//echo $requete;
			$rep = $bdd->query($requete); 
			
			while ($ligne = $rep ->fetch()){
			echo  "<p class='liste'><a href='commune_spe.php?idd=".$ligne['code_dep']." & ids=".$ligne['code_spe'].
			"'>".$ligne['nom_dep'].'</a></p>';
			}
		?>
		
	</div>
	 
	<div class='stat'>
		<table class="eff">
		<?php	
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			
			$req='select sum(effectif) as somme, nom_dep, nom_spe from situer, specialite, iris, departement
					where situer.code_spe=specialite.code_spe and situer.id_iris=iris.id_iris
					and iris.code_dep=departement.code_dep and situer.code_spe='.$_GET["ids"].' and iris.code_reg='
					.$_GET["idr"].' group by nom_dep order by somme DESC';
			
			//echo $req;
			
			$rep = $bdd->query($req); 
			
			$ligne = $rep ->fetch();
			
			echo '<h3>Classement du total des effectifs par département de la spécialité ';
			echo $ligne['nom_spe'].'</h3>';
			echo '<tr><th>Nom du département</th>
				<th>Effectif total</th></tr>';
			echo '<tr><td class="cell">'.$ligne['nom_dep'].'</td>';
			echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
				
			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['nom_dep'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>
	
	<a href='specialite.php' class='retour'>Retour</a>

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>