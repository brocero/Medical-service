<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>
 
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>

	
	<img src="image/images.jpeg" class='ima'>
	
			<div class='onglet'>
		<table class='eff'>
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 

			$req='select sum(effectif) as somme, nom_spe, lib_com from situer, specialite, commune, iris
				where situer.code_spe=specialite.code_spe and iris.id_iris=situer.id_iris 
				and iris.code_com=commune.code_com and iris.code_com='.$_GET['idi'].'
				group by nom_spe order by nom_spe';
		
			$rep = $bdd->query($req); 

			//echo $req;
			
				$ligne = $rep ->fetch();
			
			echo '<h3>Classement du total des effectifs par spécialité de la ville :	';
			echo $ligne['lib_com'];
			echo "<tr><th>Nom de la spécialité</th>
				<th>Effectif total</th></tr>";
				
			echo '<tr><td class="cell">'.$ligne['nom_spe'].'</td>';
			echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			
			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['nom_spe'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>
	
	<div class='stat'>
		<table class='eff'>
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 

			$req='SELECT lib_com, lib_iris, sum(effectif )as somme from iris, situer , commune
					where iris.id_iris=situer.id_iris  and iris.code_com=commune.code_com 
					and iris.code_com='.$_GET['idi'].' and commune.code_com='.$_GET['idi'].' GROUP by lib_iris ORDER by somme DESC';
					
			//echo $req;
			$rep = $bdd->query($req); 
 
			$ligne = $rep ->fetch();
			
			echo '<h3>Classement du total des effectifs par iris de toutes les spécialités dans la ville :	';
			echo $ligne['lib_com'];
			echo "<tr><th>Nom de l'iris</th>
				<th>Effectif total</th></tr>";
 
			echo '<tr><td class="cell">'.$ligne['lib_iris'].'</td>';
			echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
 
			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['lib_iris'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>
	

	<a href='localite.php' class='retour'>Retour</a>
	
	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>