<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
 <h1>Medical Service </h1>

 <div class="recherche_spe"> 
		<form>	
			<br>Recherche par spécialité : <input type = "text"></br>
		</form>
 </div>
 <div class="boite">
 
 
 </div>
 
<p><a href="index.php">Accueil</a></p>

<table class="tab">
<tr><th class="footer">CGU</th>
	<th class="footer">FAQ</th>
	<th class="footer">Contact</th>
	<th class="footer">Sources</th>
</tr>
</table>

</body>
</html>