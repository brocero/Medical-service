<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>

	<table class="tab">
					<tr><th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
 
	<!--<div class="recherche_spe"> 
		<form>	
			<br>Recherche par spécialité : <input type = "text"></br>
		</form>
	</div> -->
 <img src="image/docteur.jpeg" class='ima'>
	<div class="onglet">
	<?php
		echo '<h3>'.'Rechercher une spécialité : '.'</h3>';
		$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 

		$rep = $bdd->query('select nom_spe, code_spe FROM specialite ORDER BY nom_spe ASC'); 

 /*echo ('<select name="reg">');
	while ($ligne = $rep ->fetch()) {
		echo "<option value='".$ligne["nom_reg"]."'>".$ligne["nom_reg"]."</option>\n";
	}
	echo ('</select>');*/
 
 
		while ($ligne = $rep ->fetch()) {
			echo "<p class='liste'><a href='region_spe.php?ids=".$ligne['code_spe']."'>".$ligne['nom_spe'].'</a></p>';
		}

	?>
 
	</div>
 
	<div class='stat'>
		<table class='eff'>
		<?php
		
			echo '<h3>Classement du total des effectifs par spécialité en France en 2016</h3>';
			
			echo '<tr><th>Nom de la spécialité</th>
				<th>Effectif total</th></tr>';
				
			
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 

			$rep = $bdd->query('select sum(effectif) as somme, nom_spe from situer, specialite
								where situer.code_spe=specialite.code_spe group by nom_spe
								order by somme DESC'); 

			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['nom_spe'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>


	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>


</body>
</html>