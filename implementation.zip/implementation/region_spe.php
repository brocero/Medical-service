<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>

	<table class="tab">
					<tr><th><h2><a href="localite.php">Localité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
 
	<!--<div class="recherche_spe"> ;
		<form>	
			<br>Recherche par spécialité : <input type = "text"></br>
		</form>
	</div> -->
 <img src="image/docteur.jpeg" class='ima'>	
	<div class="onglet">
		<?php
		echo'<h3>Choisissez une région :</h3>';
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			//print_r($_GET);
			$requete = "select distinct region.nom_reg, region.code_reg, situer.code_spe from region, iris, situer where iris.id_iris=situer
				.id_iris and region.code_reg=iris.code_reg and situer.effectif != 0 and code_spe=".$_GET["ids"]." order by region.nom_reg";
			//echo $requete;
			
			$rep = $bdd->query($requete); 
			while ($ligne = $rep ->fetch()){
			echo "<p class='liste'><a href='departement_spe.php?idr=".$ligne['code_reg']." & ids=".$ligne['code_spe']."'>".$ligne['nom_reg']
			.'</a></p>';
	
			}
		?>
	</div>
	
	<div class='stat'>
		<table class="eff">
		<?php	
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			
			$req='select sum(effectif) as somme, nom_reg, nom_spe from situer, specialite, iris, region
					where situer.code_spe=specialite.code_spe	and situer.id_iris=iris.id_iris
					and iris.code_reg=region.code_reg and situer.code_spe='.$_GET["ids"].'
					group by nom_reg order by somme DESC';
			
			//echo $req;
			
			$rep = $bdd->query($req); 
			
			$ligne = $rep ->fetch();
			
			echo '<h3>Classement du total des effectifs par région de la spécialité ';
			echo $ligne['nom_spe'].'</h3>';
			echo '<tr><th>Nom de la région</th>
				<th>Effectif total</th></tr>';
			
			echo '<tr><td class="cell">'.$ligne['nom_reg'].'</td>';
			echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			
			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['nom_reg'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>

	<a href='specialite.php' class='retour'>Retour</a>
	
	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>