<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>
 
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>
	
	<div class="recherche_loca"> 
		Rechercher une commune :
		<select name="reg" onChange="window.location = 'iris_loca.php?idi='+this.options[this.selectedIndex].value;">
	<?php
		$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
		$rep = $bdd->query('select lib_com, code_com FROM commune ORDER BY lib_com ASC'); 

			while ($ligne = $rep ->fetch()) {
				echo"<option value='".$ligne["code_com"]."'>".$ligne["lib_com"]."</option>";
			}
		echo ('</select>');
	?>
	</div>
	
	<img src="image/images.jpeg" class='ima'>
	
	<div class="onglet">
	<?php
		echo '<h3>Rechercher une région : </h3>';
		$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 

		$rep = $bdd->query('select nom_reg, code_reg FROM region ORDER BY nom_reg ASC'); 
 
		while ($ligne = $rep ->fetch()) {
				
			echo "<p class='liste'><a href='departement_loca.php?id=".$ligne['code_reg']."'>".$ligne['nom_reg']."</a></p>";
		}

	?>
	</div>
	
	<div class='stat'>
		<table class='eff'>
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 

			$req='SELECT nom_reg, sum(effectif )as somme from iris, situer , region 
					where iris.id_iris=situer.id_iris  and region.code_reg=iris.code_reg
					GROUP by nom_reg ORDER by somme DESC';
			//echo $req;
			$rep = $bdd->query($req); 
 
			echo '<h3>Classement du total des effectifs par région de toutes les spécialité ';
			echo '<tr><th>Nom de la région</th>
				<th>Effectif total</th></tr>';
 
			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['nom_reg'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>
	
	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>