<!DOCTYPE html>
<html>
<head>
 <title>Medical Service</title>
 <meta http-equiv="Content-Type"content="text/html; charset=UTF-8" /> 
 <link rel="stylesheet"	href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<h1><img src='image/logo.png' class='logo'> </h1>
 
	<table class="tab">
					<tr><th><h2><a href="specialite.php">Spécialité</a></h2></th>
						<th><h2><a href="index.php">Accueil</a></h2></th>
					</tr>
	</table>

		<img src="image/images.jpeg" class='ima'>
	
	<div class="onglet">
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 
			//print_r($_GET);
			$rep = $bdd->query('select nom_dep, code_dep from departement where code_reg='.$_GET["id"]); 
			
			while ($ligne = $rep ->fetch()){
				echo "<p class='liste'><a href='spe_loca.php?idd=".$ligne['code_dep']."'>".$ligne['nom_dep'].'</a></p>';
			}
		?>
	</div>
	
	
	<div class='stat'>
				<table class='eff'>
		<?php
			$bdd = new PDO('mysql:host=localhost;dbname=projet_l3;charset=utf8', 'root', 'root'); 

			$req='SELECT nom_dep, sum(effectif )as somme, nom_reg from iris, situer , departement, region
					where iris.id_iris=situer.id_iris  and region.code_reg=iris.code_reg and
					departement.code_dep=iris.code_dep and iris.code_reg='.$_GET['id'].'
					 GROUP by nom_dep ORDER by somme DESC';
			//echo $req;
			$rep = $bdd->query($req); 
 
			$ligne = $rep ->fetch();
			
			echo '<h3>Classement du total des effectifs par département de toutes les spécialité dans la région ';
			echo  $ligne['nom_reg'].'</h3>';
			echo '<tr><th>Nom du département</th>
				<th>Effectif total</th></tr>';
				
			echo '<tr><td class="cell">'.$ligne['nom_dep'].'</td>';
			echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
				
			while ($ligne = $rep ->fetch()) {
				echo '<tr><td class="cell">'.$ligne['nom_dep'].'</td>';
				echo '<td class="cell">'.$ligne['somme'].'</td></tr>';
			}
		?>
		</table>
	</div>
	
	
	<a href='localite.php' class='retour'>Retour</a>

	<table class="tab">
		<tr>
			<th class="footer"><a href="FAQ.php">FAQ</a></th>
			<th class="footer"><a href="contact.php">Contact</a></th>
			<th class="footer"><a href="source.php">Sources</a></th>
		</tr>
	</table>

</body>
</html>